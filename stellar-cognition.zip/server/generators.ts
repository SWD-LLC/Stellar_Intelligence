import { invokeLLM } from './_core/llm';

export interface Star {
  id: number;
  name: string;
  spectralClass: string;
  temperature: number;
  luminosity: number;
  distance: number;
  mass: number;
  radius: number;
  constellation: string;
  lifecycleStage: string;
  elementOrigins: string;
}

export type ExplanationMode = 'student' | 'public' | 'research' | 'nasa_stem';

export async function generateAIExplanation(
  star: Star | null,
  mode: ExplanationMode
): Promise<string> {
  if (!star) {
    return 'Select a star to generate an explanation.';
  }

  const modePrompts: Record<ExplanationMode, string> = {
    student: `Explain ${star.name} (${star.spectralClass}) in simple terms for a high school student. Focus on what makes this star special and easy-to-understand facts about its size, brightness, and temperature.`,
    public: `Write a poetic but scientifically accurate description of ${star.name}. Include its spectral class (${star.spectralClass}), temperature (${star.temperature}K), and luminosity (${star.luminosity}L☉). Make it engaging for a general audience.`,
    research: `Provide a technical analysis of ${star.name}'s classification. Discuss its spectral type (${star.spectralClass}), H-R diagram position, mass (${star.mass}M☉), and evolutionary stage. Include observational evidence and uncertainties.`,
    nasa_stem: `Create an outreach explanation of ${star.name} suitable for STEM education. Connect its properties (temperature: ${star.temperature}K, luminosity: ${star.luminosity}L☉, mass: ${star.mass}M☉) to fundamental physics concepts and space exploration.`,
  };

  try {
    const response = await invokeLLM({
      messages: [
        {
          role: 'system',
          content: 'You are an expert astronomer and science communicator. Provide accurate, engaging explanations of stellar properties.',
        },
        {
          role: 'user',
          content: modePrompts[mode],
        },
      ],
    });

    const content = response.choices[0]?.message?.content;
    const textContent = typeof content === 'string' ? content : '';
    return textContent || 'Unable to generate explanation.';
  } catch (error) {
    console.error('Error generating explanation:', error);
    return `Explanation for ${star.name} in ${mode} mode.`;
  }
}

export function generateEvidenceTrail(star: Star | null): Array<{
  type: string;
  evidence: string;
  confidence: number;
  note?: string;
}> {
  if (!star) {
    return [];
  }

  const evidenceCards = [];

  // Spectral class evidence
  evidenceCards.push({
    type: 'Spectral Class',
    evidence: `${star.spectralClass} classification based on absorption lines and temperature ${star.temperature}K`,
    confidence: 0.95,
    note: 'Primary classification method',
  });

  // Temperature evidence
  evidenceCards.push({
    type: 'Temperature',
    evidence: `Surface temperature of ${star.temperature}K determined from spectral analysis and color index`,
    confidence: 0.92,
  });

  // Luminosity evidence
  evidenceCards.push({
    type: 'Luminosity',
    evidence: `Luminosity of ${star.luminosity.toFixed(2)}L☉ calculated from distance (${star.distance}ly) and apparent magnitude`,
    confidence: 0.88,
    note: 'Distance measurements have ±5% uncertainty',
  });

  // Color evidence
  const colorMap: Record<string, string> = {
    O: 'Blue',
    B: 'Blue-white',
    A: 'White',
    F: 'Yellow-white',
    G: 'Yellow',
    K: 'Orange',
    M: 'Red',
  };
  const color = colorMap[star.spectralClass.charAt(0)] || 'Unknown';
  evidenceCards.push({
    type: 'Color',
    evidence: `${color} color consistent with ${star.temperature}K temperature`,
    confidence: 0.93,
  });

  // Mass evidence
  evidenceCards.push({
    type: 'Mass',
    evidence: `Mass of ${star.mass.toFixed(2)}M☉ estimated from mass-luminosity relation and spectral type`,
    confidence: 0.85,
    note: 'Mass estimates have ±15% uncertainty for main sequence stars',
  });

  // Lifecycle stage evidence
  evidenceCards.push({
    type: 'Lifecycle Stage',
    evidence: `${star.lifecycleStage} stage inferred from H-R position and luminosity class`,
    confidence: 0.90,
  });

  return evidenceCards;
}

export function generateEvolutionTimeline(star: Star | null): Array<{
  stage: string;
  duration: string;
  description: string;
}> {
  if (!star) {
    return [];
  }

  const timeline: Array<{ stage: string; duration: string; description: string }> = [];

  if (star.mass < 0.5) {
    // Low mass star
    timeline.push(
      {
        stage: 'Molecular Cloud',
        duration: '~100,000 years',
        description: 'Gravitational collapse begins in interstellar dust cloud',
      },
      {
        stage: 'Protostar',
        duration: '~100,000 years',
        description: 'Accretion disk forms, temperature rises toward fusion threshold',
      },
      {
        stage: 'Main Sequence',
        duration: '100+ billion years',
        description: `${star.name} is here - stable hydrogen fusion in core`,
      },
      {
        stage: 'Red Dwarf',
        duration: 'Billions of years',
        description: 'Gradual expansion and cooling as hydrogen depletes',
      },
      {
        stage: 'White Dwarf',
        duration: 'Trillions of years',
        description: 'Cooling remnant, eventually becomes black dwarf',
      }
    );
  } else if (star.mass < 8) {
    // Medium mass star
    timeline.push(
      {
        stage: 'Molecular Cloud',
        duration: '~100,000 years',
        description: 'Gravitational collapse begins',
      },
      {
        stage: 'Protostar',
        duration: '~100,000 years',
        description: 'Accretion and heating phase',
      },
      {
        stage: 'Main Sequence',
        duration: '~10 billion years',
        description: `${star.name} is here - hydrogen fusion`,
      },
      {
        stage: 'Red Giant',
        duration: '~1-2 billion years',
        description: 'Envelope expands, core contracts, helium fusion begins',
      },
      {
        stage: 'Planetary Nebula',
        duration: '~10,000 years',
        description: 'Outer layers ejected, creating expanding shell',
      },
      {
        stage: 'White Dwarf',
        duration: 'Trillions of years',
        description: 'Cooling stellar remnant',
      }
    );
  } else if (star.mass < 20) {
    // High mass star
    timeline.push(
      {
        stage: 'Molecular Cloud',
        duration: '~100,000 years',
        description: 'Rapid gravitational collapse',
      },
      {
        stage: 'Protostar',
        duration: '~100,000 years',
        description: 'Rapid accretion and heating',
      },
      {
        stage: 'Massive Main Sequence',
        duration: '~10 million years',
        description: `${star.name} is here - rapid hydrogen fusion`,
      },
      {
        stage: 'Red Supergiant',
        duration: '~1 million years',
        description: 'Extreme expansion, multiple fusion stages',
      },
      {
        stage: 'Supernova',
        duration: 'Seconds to minutes',
        description: 'Catastrophic core collapse and explosion',
      },
      {
        stage: 'Neutron Star',
        duration: 'Billions of years',
        description: 'Ultra-dense stellar remnant',
      }
    );
  } else {
    // Very high mass star
    timeline.push(
      {
        stage: 'Molecular Cloud',
        duration: '~100,000 years',
        description: 'Rapid collapse',
      },
      {
        stage: 'Protostar',
        duration: '~100,000 years',
        description: 'Intense accretion',
      },
      {
        stage: 'Massive Main Sequence',
        duration: '~1-10 million years',
        description: `${star.name} is here - extreme fusion`,
      },
      {
        stage: 'Blue Hypergiant',
        duration: '~100,000 years',
        description: 'Extreme luminosity and mass loss',
      },
      {
        stage: 'Supernova',
        duration: 'Seconds to minutes',
        description: 'Pair-instability or core-collapse explosion',
      },
      {
        stage: 'Black Hole',
        duration: 'Infinite',
        description: 'Gravitational singularity',
      }
    );
  }

  return timeline;
}

export interface TelescopeCoachInput {
  imageClarity: number; // 0-100
  lightPollution: number; // 0-100
  exposureLength: number; // seconds
  location: string;
  timeOfNight: string;
  targetObject: string;
}

export function generateTelescopeCoach(input: TelescopeCoachInput): {
  qualityRating: number;
  recommendation: string;
  severity: 'Low' | 'Medium' | 'High';
  explanation: string;
} {
  let qualityRating = 50;
  let recommendation = '';
  let severity: 'Low' | 'Medium' | 'High' = 'Low';
  let explanation = '';

  // Assess image clarity
  if (input.imageClarity < 30) {
    qualityRating -= 20;
    recommendation += 'Improve focus and collimation. ';
    severity = 'High';
  } else if (input.imageClarity < 60) {
    qualityRating -= 10;
    recommendation += 'Fine-tune focus. ';
  }

  // Assess light pollution
  if (input.lightPollution > 70) {
    qualityRating -= 25;
    recommendation += 'Travel to darker skies. ';
    severity = 'High';
    explanation = 'Light pollution severely reduces contrast and faint object visibility.';
  } else if (input.lightPollution > 40) {
    qualityRating -= 15;
    recommendation += 'Use light pollution filters. ';
    severity = 'Medium';
  }

  // Assess exposure
  if (input.exposureLength < 5) {
    recommendation += 'Increase exposure time for better signal-to-noise. ';
  } else if (input.exposureLength > 120) {
    recommendation += 'Reduce exposure to avoid trailing. ';
  }

  // Time of night assessment
  if (input.timeOfNight.includes('midnight') || input.timeOfNight.includes('2') || input.timeOfNight.includes('3')) {
    qualityRating += 10;
    explanation = 'Optimal observing time - atmosphere is most stable.';
  }

  qualityRating = Math.min(100, Math.max(0, qualityRating));

  return {
    qualityRating,
    recommendation: recommendation.trim() || 'Conditions are good for observation.',
    severity,
    explanation: explanation || 'Current conditions are suitable for observing.',
  };
}

export function generateChallengeFeedback(
  selectedChallenge: number,
  submittedAnswer: number,
  correctAnswer: number
): {
  isCorrect: boolean;
  explanation: string;
  completionStatus: string;
} {
  const isCorrect = submittedAnswer === correctAnswer;

  return {
    isCorrect,
    explanation: isCorrect
      ? 'Excellent! Your answer demonstrates understanding of stellar classification.'
      : 'Not quite right. Review the stellar properties and try again.',
    completionStatus: isCorrect ? 'Completed' : 'In Progress',
  };
}

export interface JournalEntry {
  date: string;
  selectedStar: string;
  observationType: string;
  userNotes: string;
  aiTakeaway: string;
  hrPlacement: string;
  confidenceScore: number;
  uncertaintyNote: string;
  suggestedNextObservation: string;
}

export function generateJournalEntry(
  star: Star | null,
  observationType: string,
  userNotes: string,
  aiTakeaway: string
): JournalEntry | null {
  if (!star) {
    return null;
  }

  const hrPlacement = star.luminosity > 10 
    ? (star.temperature < 5000 ? 'Red Giant Branch' : 'Supergiant Region')
    : 'Main Sequence';

  return {
    date: new Date().toISOString(),
    selectedStar: star.name,
    observationType,
    userNotes,
    aiTakeaway,
    hrPlacement,
    confidenceScore: 0.88,
    uncertaintyNote: `Distance measurement uncertainty: ±5%. Mass estimate uncertainty: ±15% for main sequence stars.`,
    suggestedNextObservation: `Compare ${star.name} with other ${star.spectralClass.charAt(0)}-type stars to understand stellar diversity.`,
  };
}

export async function generateStellarReport(star: Star | null): Promise<string> {
  if (!star) {
    return 'Select a star before generating a report.';
  }

  const timeline = generateEvolutionTimeline(star);
  const evidence = generateEvidenceTrail(star);

  const report: string = `
STELLAR COGNITION REPORT
Generated: ${new Date().toLocaleString()}
Star: ${star.name}

═══════════════════════════════════════════════════════════════════════════════

OBSERVATION SUMMARY
──────────────────────────────────────────────────────────────────────────────
${star.name} is a ${star.spectralClass} class star located in the constellation ${star.constellation}, 
approximately ${star.distance.toFixed(2)} light-years from Earth. With a surface temperature of 
${star.temperature}K and luminosity of ${star.luminosity.toFixed(2)}L☉, this star represents a 
${star.lifecycleStage} stage stellar object.

STAR BIOGRAPHY
──────────────────────────────────────────────────────────────────────────────
Name: ${star.name}
Spectral Class: ${star.spectralClass}
Temperature: ${star.temperature}K
Luminosity: ${star.luminosity.toFixed(2)}L☉
Mass: ${star.mass.toFixed(3)}M☉
Radius: ${star.radius.toFixed(3)}R☉
Distance: ${star.distance.toFixed(2)} light-years
Constellation: ${star.constellation}
Lifecycle Stage: ${star.lifecycleStage}

H-R DIAGRAM PLACEMENT
──────────────────────────────────────────────────────────────────────────────
Temperature (log scale): ${Math.log10(star.temperature).toFixed(2)}
Luminosity (log scale): ${Math.log10(star.luminosity).toFixed(2)}
Classification Region: ${star.luminosity > 10 ? (star.temperature < 5000 ? 'Red Giant' : 'Supergiant') : 'Main Sequence'}

EVIDENCE TRAIL
──────────────────────────────────────────────────────────────────────────────
${evidence.map((e) => `${e.type}: ${e.evidence} (Confidence: ${(e.confidence * 100).toFixed(0)}%)`).join('\n')}

STELLAR LIFECYCLE
──────────────────────────────────────────────────────────────────────────────
${timeline.map((t) => `${t.stage} (${t.duration}): ${t.description}`).join('\n')}

ELEMENT ORIGINS
──────────────────────────────────────────────────────────────────────────────
Primary elements: Hydrogen (primordial), Helium (fusion), Carbon (triple-alpha), 
Nitrogen (CNO cycle), Oxygen (fusion), Iron (supernova nucleosynthesis)

LEARNING TAKEAWAY
──────────────────────────────────────────────────────────────────────────────
${star.name} demonstrates the fundamental principles of stellar classification, 
energy generation through nuclear fusion, and the connection between a star's 
properties and its evolutionary destiny.

SUGGESTED NEXT OBSERVATION
──────────────────────────────────────────────────────────────────────────────
Compare ${star.name} with other ${star.spectralClass.charAt(0)}-type stars to understand 
stellar diversity and the mass-luminosity relationship.

═══════════════════════════════════════════════════════════════════════════════
Report generated by Stellar Cognition
AI-Enhanced Hertzsprung-Russell Diagram and Stellar Classification System
  `;

  return report;
}
