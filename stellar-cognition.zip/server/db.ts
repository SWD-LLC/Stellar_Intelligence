import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, stars, hrPlacements, evidenceRecords, lifecyclePaths, elementOrigins, aiExplanations, stellarReports, observationSessions, stemChallenges } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Stellar Cognition Queries

export async function getAllStars() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(stars);
}

export async function getStarById(starId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(stars).where(eq(stars.id, starId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getStarByName(name: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(stars).where(eq(stars.name, name)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getHRPlacementForStar(starId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(hrPlacements).where(eq(hrPlacements.starId, starId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getEvidenceForStar(starId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(evidenceRecords).where(eq(evidenceRecords.starId, starId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getLifecyclePathForStar(starId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(lifecyclePaths).where(eq(lifecyclePaths.starId, starId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getElementOriginsForStar(starId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(elementOrigins).where(eq(elementOrigins.starId, starId));
}

export async function getAIExplanationForStar(starId: number, mode: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(aiExplanations)
    .where(eq(aiExplanations.starId, starId))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createAIExplanation(starId: number, mode: string, explanation: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(aiExplanations).values({
    starId,
    mode: mode as any,
    explanation,
  });
  return result;
}

export async function createStellarReport(userId: number, starId: number, reportData: any) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(stellarReports).values({
    userId,
    starId,
    observationSummary: reportData.observationSummary,
    hrPlacement: reportData.hrPlacement,
    biography: reportData.biography,
    lifecycleInterpretation: reportData.lifecycleInterpretation,
    evidenceTrail: reportData.evidenceTrail,
    uncertaintyStatement: reportData.uncertaintyStatement,
    learningTakeaway: reportData.learningTakeaway,
    suggestedNextObservation: reportData.suggestedNextObservation,
    reportContent: JSON.stringify(reportData),
  });
  return result;
}

export async function createObservationSession(userId: number, starId: number, sessionData: any) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(observationSessions).values({
    userId,
    selectedStarId: starId,
    imageClarityLevel: sessionData.imageClarityLevel,
    lightPollutionLevel: sessionData.lightPollutionLevel,
    exposureLength: sessionData.exposureLength,
    location: sessionData.location,
    timeOfNight: sessionData.timeOfNight,
    coachGuidance: sessionData.coachGuidance,
  });
  return result;
}

export async function createSTEMChallenge(userId: number, challengeData: any) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(stemChallenges).values({
    userId,
    challengeType: challengeData.challengeType,
    description: challengeData.description,
    correctAnswer: challengeData.correctAnswer,
    userAnswer: challengeData.userAnswer,
    isCompleted: challengeData.isCompleted ? 1 : 0,
  });
  return result;
}

export async function updateSTEMChallengeCompletion(challengeId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.update(stemChallenges)
    .set({ isCompleted: 1, completedAt: new Date() })
    .where(eq(stemChallenges.id, challengeId));
  return result;
}
