import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "../_core/trpc";
import { getAllStars, getStarById, getAIExplanationForStar, createAIExplanation } from "../db";
import { invokeLLM } from "../_core/llm";
import {
  generateAIExplanation,
  generateEvidenceTrail,
  generateEvolutionTimeline,
  generateTelescopeCoach,
  generateChallengeFeedback,
  generateJournalEntry,
  generateStellarReport,
  type TelescopeCoachInput,
} from "../generators";

const ModeEnum = z.enum(["student", "public", "research", "nasa_stem"]);

export const stellarRouter = router({
  getAllStars: publicProcedure.query(async () => {
    const allStars = await getAllStars();
    return allStars.map((star) => ({
      id: star.id,
      name: star.name,
      spectralClass: star.spectralClass,
      temperature: Number(star.temperature),
      luminosity: Number(star.luminosity),
      distance: Number(star.distance),
      mass: Number(star.mass),
      radius: Number(star.radius),
      constellation: star.constellation,
      lifecycleStage: star.lifecycleStage,
      confidenceScore: Number(star.confidenceScore),
      dataSource: star.dataSource,
      uncertaintyNote: star.uncertaintyNote,
      elementOrigins: typeof star.elementOrigins === 'string' ? JSON.parse(star.elementOrigins) : star.elementOrigins,
    }));
  }),

  getStarDetail: publicProcedure.input(z.object({ starId: z.number() })).query(async ({ input }) => {
    const star = await getStarById(input.starId);
    if (!star) return null;
    return {
      id: star.id,
      name: star.name,
      spectralClass: star.spectralClass,
      temperature: Number(star.temperature),
      luminosity: Number(star.luminosity),
      distance: Number(star.distance),
      mass: Number(star.mass),
      radius: Number(star.radius),
      constellation: star.constellation,
      lifecycleStage: star.lifecycleStage,
      confidenceScore: Number(star.confidenceScore),
      dataSource: star.dataSource,
      uncertaintyNote: star.uncertaintyNote,
      elementOrigins: typeof star.elementOrigins === 'string' ? JSON.parse(star.elementOrigins) : star.elementOrigins,
    };
  }),

  generateExplanation: publicProcedure
    .input(z.object({ starId: z.number(), mode: ModeEnum }))
    .mutation(async ({ input }) => {
      const star = await getStarById(input.starId);
      if (!star) throw new Error("Star not found");

      const cached = await getAIExplanationForStar(input.starId, input.mode);
      if (cached) return { explanation: cached.explanation };

      const modePrompts: Record<string, string> = {
        student: `Explain ${star.name} in simple terms for a high school student.`,
        public: `Write a poetic but accurate description of ${star.name}.`,
        research: `Provide technical analysis of ${star.name}.`,
        nasa_stem: `Create STEM education explanation of ${star.name}.`,
      };
      const mode = input.mode as keyof typeof modePrompts;

      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: `You are an expert astronomer. Provide clear, accurate explanations about stars.`,
          },
          {
            role: "user",
            content: `${modePrompts[input.mode]} Star: ${star.name}, Temp: ${star.temperature}K, Luminosity: ${star.luminosity} L☉, Class: ${star.spectralClass}`,
          },
        ],
      });

      const content = response.choices[0]?.message?.content;
      const explanation = typeof content === 'string' ? content : '';
      await createAIExplanation(input.starId, input.mode, explanation);

      return { explanation: explanation || "" };
    }),

  generateAIExplanationV2: publicProcedure
    .input(z.object({ starId: z.number().nullable(), mode: ModeEnum }))
    .query(async ({ input }) => {
      if (!input.starId) {
        return { explanation: 'Select a star to generate an explanation.' };
      }
      const star = await getStarById(input.starId);
      if (!star) {
        return { explanation: 'Star not found.' };
      }
      const explanation = await generateAIExplanation(
        {
          id: star.id,
          name: star.name,
          spectralClass: star.spectralClass,
          temperature: Number(star.temperature),
          luminosity: Number(star.luminosity),
          distance: Number(star.distance),
          mass: Number(star.mass),
          radius: Number(star.radius),
          constellation: star.constellation,
          lifecycleStage: star.lifecycleStage,
          elementOrigins: star.elementOrigins || '',
        },
        input.mode
      );
      return { explanation: explanation || "" };
    }),

  generateEvidenceTrail: publicProcedure
    .input(z.object({ starId: z.number().nullable() }))
    .query(async ({ input }) => {
      if (!input.starId) {
        return { evidence: [] };
      }
      const star = await getStarById(input.starId);
      if (!star) {
        return { evidence: [] };
      }
      const evidence = generateEvidenceTrail({
        id: star.id,
        name: star.name,
        spectralClass: star.spectralClass,
        temperature: Number(star.temperature),
        luminosity: Number(star.luminosity),
        distance: Number(star.distance),
        mass: Number(star.mass),
        radius: Number(star.radius),
        constellation: star.constellation,
        lifecycleStage: star.lifecycleStage,
        elementOrigins: star.elementOrigins || '',
      });
      return { evidence: evidence || [] };
    }),

  generateEvolutionTimeline: publicProcedure
    .input(z.object({ starId: z.number().nullable() }))
    .query(async ({ input }) => {
      if (!input.starId) {
        return { timeline: [] };
      }
      const star = await getStarById(input.starId);
      if (!star) {
        return { timeline: [] };
      }
      const timeline = generateEvolutionTimeline({
        id: star.id,
        name: star.name,
        spectralClass: star.spectralClass,
        temperature: Number(star.temperature),
        luminosity: Number(star.luminosity),
        distance: Number(star.distance),
        mass: Number(star.mass),
        radius: Number(star.radius),
        constellation: star.constellation,
        lifecycleStage: star.lifecycleStage,
        elementOrigins: star.elementOrigins || '',
      });
      return { timeline: timeline || [] };
    }),

  generateTelescopeCoach: publicProcedure
    .input(
      z.object({
        imageClarity: z.number(),
        lightPollution: z.number(),
        exposureLength: z.number(),
        location: z.string(),
        timeOfNight: z.string(),
        targetObject: z.string(),
      })
    )
    .query(({ input }) => {
      const coachResult = generateTelescopeCoach(input as TelescopeCoachInput);
      return coachResult;
    }),

  generateChallengeFeedback: publicProcedure
    .input(
      z.object({
        selectedChallenge: z.number(),
        submittedAnswer: z.number(),
        correctAnswer: z.number(),
      })
    )
    .query(({ input }) => {
      const feedback = generateChallengeFeedback(
        input.selectedChallenge,
        input.submittedAnswer,
        input.correctAnswer
      );
      return feedback;
    }),

  generateStellarReport: publicProcedure
    .input(z.object({ starId: z.number().nullable() }))
    .query(async ({ input }) => {
      if (!input.starId) {
        return { report: 'Select a star before generating a report.' };
      }
      const star = await getStarById(input.starId);
      if (!star) {
        return { report: 'Star not found.' };
      }
      const report = await generateStellarReport({
        id: star.id,
        name: star.name,
        spectralClass: star.spectralClass,
        temperature: Number(star.temperature),
        luminosity: Number(star.luminosity),
        distance: Number(star.distance),
        mass: Number(star.mass),
        radius: Number(star.radius),
        constellation: star.constellation,
        lifecycleStage: star.lifecycleStage,
        elementOrigins: star.elementOrigins || '',
      });
      return { report: report || "" };
    }),
});
