CREATE TABLE `aiExplanations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`starId` int NOT NULL,
	`mode` enum('student','public','research','nasa_stem') NOT NULL,
	`explanation` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `aiExplanations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `elementOrigins` (
	`id` int AUTO_INCREMENT NOT NULL,
	`starId` int NOT NULL,
	`element` varchar(32) NOT NULL,
	`abundancePercentage` decimal(10,4) NOT NULL,
	`nucleosynthesisProcess` varchar(128) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `elementOrigins_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `evidenceRecords` (
	`id` int AUTO_INCREMENT NOT NULL,
	`starId` int NOT NULL,
	`spectralClassEvidence` text,
	`temperatureEvidence` text,
	`luminosityEvidence` text,
	`colorEvidence` text,
	`catalogEvidence` text,
	`confidenceLevel` decimal(5,2) NOT NULL,
	`missingDataWarnings` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `evidenceRecords_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `hrPlacements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`starId` int NOT NULL,
	`xPosition` decimal(10,4) NOT NULL,
	`yPosition` decimal(10,4) NOT NULL,
	`hrRegion` varchar(64) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `hrPlacements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `lifecyclePaths` (
	`id` int AUTO_INCREMENT NOT NULL,
	`starId` int NOT NULL,
	`pathType` varchar(64) NOT NULL,
	`stages` json NOT NULL,
	`currentStageIndex` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `lifecyclePaths_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `observationSessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`selectedStarId` int NOT NULL,
	`imageClarityLevel` varchar(32),
	`lightPollutionLevel` varchar(32),
	`exposureLength` int,
	`location` varchar(256),
	`timeOfNight` varchar(32),
	`coachGuidance` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `observationSessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stars` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(128) NOT NULL,
	`spectralClass` varchar(16) NOT NULL,
	`temperature` int NOT NULL,
	`luminosity` decimal(10,4) NOT NULL,
	`distance` decimal(10,2) NOT NULL,
	`mass` decimal(10,4) NOT NULL,
	`radius` decimal(10,4) NOT NULL,
	`constellation` varchar(64) NOT NULL,
	`lifecycleStage` varchar(64) NOT NULL,
	`confidenceScore` decimal(5,2) NOT NULL,
	`dataSource` varchar(256) NOT NULL,
	`uncertaintyNote` text,
	`elementOrigins` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `stars_id` PRIMARY KEY(`id`),
	CONSTRAINT `stars_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `stellarReports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`starId` int NOT NULL,
	`observationSummary` text,
	`hrPlacement` text,
	`biography` text,
	`lifecycleInterpretation` text,
	`evidenceTrail` text,
	`uncertaintyStatement` text,
	`learningTakeaway` text,
	`suggestedNextObservation` text,
	`reportContent` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stellarReports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stemChallenges` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`challengeType` varchar(128) NOT NULL,
	`description` text NOT NULL,
	`correctAnswer` text,
	`userAnswer` text,
	`isCompleted` int DEFAULT 0,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stemChallenges_id` PRIMARY KEY(`id`)
);
