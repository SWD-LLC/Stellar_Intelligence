import { decimal, int, json, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Stellar Cognition Tables

export const stars = mysqlTable("stars", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 128 }).notNull().unique(),
  spectralClass: varchar("spectralClass", { length: 16 }).notNull(),
  temperature: int("temperature").notNull(), // Kelvin
  luminosity: decimal("luminosity", { precision: 10, scale: 4 }).notNull(), // Solar luminosities
  distance: decimal("distance", { precision: 10, scale: 2 }).notNull(), // Light-years
  mass: decimal("mass", { precision: 10, scale: 4 }).notNull(), // Solar masses
  radius: decimal("radius", { precision: 10, scale: 4 }).notNull(), // Solar radii
  constellation: varchar("constellation", { length: 64 }).notNull(),
  lifecycleStage: varchar("lifecycleStage", { length: 64 }).notNull(), // e.g., "main sequence", "red giant"
  confidenceScore: decimal("confidenceScore", { precision: 5, scale: 2 }).notNull(), // 0-100
  dataSource: varchar("dataSource", { length: 256 }).notNull(),
  uncertaintyNote: text("uncertaintyNote"),
  elementOrigins: json("elementOrigins").notNull(), // JSON array of elements
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Star = typeof stars.$inferSelect;
export type InsertStar = typeof stars.$inferInsert;

export const observationSessions = mysqlTable("observationSessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  selectedStarId: int("selectedStarId").notNull(),
  imageClarityLevel: varchar("imageClarityLevel", { length: 32 }),
  lightPollutionLevel: varchar("lightPollutionLevel", { length: 32 }),
  exposureLength: int("exposureLength"), // seconds
  location: varchar("location", { length: 256 }),
  timeOfNight: varchar("timeOfNight", { length: 32 }),
  coachGuidance: text("coachGuidance"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ObservationSession = typeof observationSessions.$inferSelect;
export type InsertObservationSession = typeof observationSessions.$inferInsert;

export const hrPlacements = mysqlTable("hrPlacements", {
  id: int("id").autoincrement().primaryKey(),
  starId: int("starId").notNull(),
  xPosition: decimal("xPosition", { precision: 10, scale: 4 }).notNull(), // Normalized temperature position
  yPosition: decimal("yPosition", { precision: 10, scale: 4 }).notNull(), // Normalized luminosity position
  hrRegion: varchar("hrRegion", { length: 64 }).notNull(), // e.g., "main sequence", "red giant", "white dwarf"
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type HRPlacement = typeof hrPlacements.$inferSelect;
export type InsertHRPlacement = typeof hrPlacements.$inferInsert;

export const aiExplanations = mysqlTable("aiExplanations", {
  id: int("id").autoincrement().primaryKey(),
  starId: int("starId").notNull(),
  mode: mysqlEnum("mode", ["student", "public", "research", "nasa_stem"]).notNull(),
  explanation: text("explanation").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AIExplanation = typeof aiExplanations.$inferSelect;
export type InsertAIExplanation = typeof aiExplanations.$inferInsert;

export const evidenceRecords = mysqlTable("evidenceRecords", {
  id: int("id").autoincrement().primaryKey(),
  starId: int("starId").notNull(),
  spectralClassEvidence: text("spectralClassEvidence"),
  temperatureEvidence: text("temperatureEvidence"),
  luminosityEvidence: text("luminosityEvidence"),
  colorEvidence: text("colorEvidence"),
  catalogEvidence: text("catalogEvidence"),
  confidenceLevel: decimal("confidenceLevel", { precision: 5, scale: 2 }).notNull(),
  missingDataWarnings: text("missingDataWarnings"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type EvidenceRecord = typeof evidenceRecords.$inferSelect;
export type InsertEvidenceRecord = typeof evidenceRecords.$inferInsert;

export const lifecyclePaths = mysqlTable("lifecyclePaths", {
  id: int("id").autoincrement().primaryKey(),
  starId: int("starId").notNull(),
  pathType: varchar("pathType", { length: 64 }).notNull(), // "low_medium_mass", "high_mass", "white_dwarf"
  stages: json("stages").notNull(), // JSON array of lifecycle stages
  currentStageIndex: int("currentStageIndex").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type LifecyclePath = typeof lifecyclePaths.$inferSelect;
export type InsertLifecyclePath = typeof lifecyclePaths.$inferInsert;

export const elementOrigins = mysqlTable("elementOrigins", {
  id: int("id").autoincrement().primaryKey(),
  starId: int("starId").notNull(),
  element: varchar("element", { length: 32 }).notNull(),
  abundancePercentage: decimal("abundancePercentage", { precision: 10, scale: 4 }).notNull(),
  nucleosynthesisProcess: varchar("nucleosynthesisProcess", { length: 128 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ElementOrigin = typeof elementOrigins.$inferSelect;
export type InsertElementOrigin = typeof elementOrigins.$inferInsert;

export const stellarReports = mysqlTable("stellarReports", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  starId: int("starId").notNull(),
  observationSummary: text("observationSummary"),
  hrPlacement: text("hrPlacement"),
  biography: text("biography"),
  lifecycleInterpretation: text("lifecycleInterpretation"),
  evidenceTrail: text("evidenceTrail"),
  uncertaintyStatement: text("uncertaintyStatement"),
  learningTakeaway: text("learningTakeaway"),
  suggestedNextObservation: text("suggestedNextObservation"),
  reportContent: text("reportContent"), // Full HTML/JSON report
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type StellarReport = typeof stellarReports.$inferSelect;
export type InsertStellarReport = typeof stellarReports.$inferInsert;

export const stemChallenges = mysqlTable("stemChallenges", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  challengeType: varchar("challengeType", { length: 128 }).notNull(),
  description: text("description").notNull(),
  correctAnswer: text("correctAnswer"),
  userAnswer: text("userAnswer"),
  isCompleted: int("isCompleted").default(0),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type STEMChallenge = typeof stemChallenges.$inferSelect;
export type InsertSTEMChallenge = typeof stemChallenges.$inferInsert;