import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Spinner } from '@/components/ui/spinner';
import { Streamdown } from 'streamdown';

type Mode = 'student' | 'public' | 'research' | 'nasa_stem';

interface ModeTabsProps {
  starId: number;
  starName: string;
  onGenerateExplanation: (mode: Mode) => Promise<{ explanation: string }>;
}

const ModeTabs: React.FC<ModeTabsProps> = ({ starId, starName, onGenerateExplanation }) => {
  const [activeMode, setActiveMode] = useState<Mode>('student');
  const [explanations, setExplanations] = useState<Record<Mode, string | null>>({
    student: null,
    public: null,
    research: null,
    nasa_stem: null,
  });
  const [loading, setLoading] = useState<Record<Mode, boolean>>({
    student: false,
    public: false,
    research: false,
    nasa_stem: false,
  });

  const modes: Array<{ id: Mode; label: string; description: string }> = [
    { id: 'student', label: 'Student', description: 'Simple & accessible' },
    { id: 'public', label: 'Public', description: 'Poetic & accurate' },
    { id: 'research', label: 'Research', description: 'Technical & detailed' },
    { id: 'nasa_stem', label: 'NASA/STEM', description: 'Outreach & learning' },
  ];

  const handleModeChange = async (mode: Mode) => {
    setActiveMode(mode);
    
    if (!explanations[mode]) {
      setLoading((prev) => ({ ...prev, [mode]: true }));
      try {
        const result = await onGenerateExplanation(mode);
        setExplanations((prev) => ({ ...prev, [mode]: result.explanation }));
      } catch (error) {
        console.error(`Failed to generate ${mode} explanation:`, error);
        setExplanations((prev) => ({
          ...prev,
          [mode]: 'Failed to generate explanation. Please try again.',
        }));
      } finally {
        setLoading((prev) => ({ ...prev, [mode]: false }));
      }
    }
  };

  return (
    <div className="w-full bg-gradient-to-b from-slate-900 to-slate-950 rounded-lg border border-cyan-500/30 p-4">
      <h3 className="text-lg font-semibold text-cyan-300 mb-4">Stellar Explanations</h3>
      
      <Tabs value={activeMode} onValueChange={(value) => handleModeChange(value as Mode)}>
        <TabsList className="grid w-full grid-cols-4 bg-slate-800 border border-cyan-500/20">
          {modes.map((mode) => (
            <TabsTrigger
              key={mode.id}
              value={mode.id}
              className="text-xs sm:text-sm data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-300"
            >
              <div className="flex flex-col items-center gap-0.5">
                <span className="font-semibold">{mode.label}</span>
                <span className="text-xs text-slate-400 hidden sm:inline">{mode.description}</span>
              </div>
            </TabsTrigger>
          ))}
        </TabsList>

        {modes.map((mode) => (
          <TabsContent key={mode.id} value={mode.id} className="mt-4">
            <div className="min-h-64 p-4 bg-slate-800/50 border border-cyan-500/20 rounded-lg">
              {loading[mode.id] ? (
                <div className="flex items-center justify-center h-64 gap-3">
                  <Spinner className="w-5 h-5" />
                  <span className="text-slate-300">Generating {mode.label} explanation...</span>
                </div>
              ) : explanations[mode.id] ? (
                <div className="prose prose-invert max-w-none text-sm text-slate-200">
                  <Streamdown>{explanations[mode.id]}</Streamdown>
                </div>
              ) : (
                <div className="text-center text-slate-400 py-8">
                  <p>Click to generate {mode.label} explanation</p>
                </div>
              )}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
};

export default ModeTabs;
