import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';

interface StarData {
  id: number;
  name: string;
  spectralClass: string;
  temperature: number;
  luminosity: number;
  distance: number;
  mass: number;
  radius: number;
  constellation: string;
  lifecycleStage: string;
  confidenceScore: number;
  dataSource: string;
  uncertaintyNote: string | null | undefined;
}

interface StarBiographyProps {
  star: StarData | null;
}

const StarBiography: React.FC<StarBiographyProps> = ({ star }) => {
  if (!star) {
    return (
      <Card className="bg-slate-900 border-cyan-500/30 p-6 h-full flex items-center justify-center">
        <div className="text-center text-slate-400">
          <p className="text-lg font-semibold">Select a star to view details</p>
          <p className="text-sm mt-2">Click on any point in the H-R Diagram</p>
        </div>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-b from-slate-900 to-slate-950 border-cyan-500/30 p-6 h-full overflow-y-auto animate-fade-in-up">
      <div className="space-y-6">
        <div className="border-b border-cyan-500/20 pb-4 animate-slide-in-left">
          <h2 className="text-2xl font-bold text-cyan-300 mb-2">{star.name}</h2>
          <div className="flex flex-wrap gap-2">
            <Badge className="bg-blue-500/20 text-blue-300 border border-blue-500/50">
              {star.spectralClass}
            </Badge>
            <Badge className="bg-orange-500/20 text-orange-300 border border-orange-500/50">
              {star.lifecycleStage}
            </Badge>
            <Badge className="bg-green-500/20 text-green-300 border border-green-500/50">
              {star.confidenceScore.toFixed(1)}% confidence
            </Badge>
          </div>
        </div>

        <div>
          <h3 className="text-sm font-semibold text-cyan-400 mb-3 uppercase tracking-wide">Physical Properties</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Temperature:</span>
              <span className="text-cyan-300 font-mono">{star.temperature.toLocaleString()} K</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Luminosity:</span>
              <span className="text-cyan-300 font-mono">{star.luminosity.toFixed(2)} L☉</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Mass:</span>
              <span className="text-cyan-300 font-mono">{star.mass.toFixed(3)} M☉</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Radius:</span>
              <span className="text-cyan-300 font-mono">{star.radius.toFixed(3)} R☉</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Distance:</span>
              <span className="text-cyan-300 font-mono">{star.distance.toFixed(2)} ly</span>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-sm font-semibold text-cyan-400 mb-3 uppercase tracking-wide">Observational Data</h3>
          <div className="space-y-2 text-sm">
            <div>
              <span className="text-slate-400">Constellation:</span>
              <p className="text-cyan-300 font-semibold">{star.constellation}</p>
            </div>
            <div>
              <span className="text-slate-400">Data Source:</span>
              <p className="text-cyan-300 text-xs">{star.dataSource}</p>
            </div>
            {star.uncertaintyNote && (
              <div className="mt-3 p-2 bg-yellow-500/10 border border-yellow-500/30 rounded text-yellow-300 text-xs">
                <p className="font-semibold mb-1">Note:</p>
                <p>{star.uncertaintyNote}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
};

export default StarBiography;
