import React, { useMemo } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface LifecycleTimelineProps {
  star: { name: string; mass: number; lifecycleStage: string } | null;
}

const LifecycleTimeline: React.FC<LifecycleTimelineProps> = ({ star }) => {
  const lifecyclePath = useMemo(() => {
    if (!star) return null;

    if (star.mass < 0.5) {
      return {
        pathType: 'Low Mass',
        stages: [
          { name: 'Molecular Cloud', duration: 'Millions of years', description: 'Gas and dust collapse' },
          { name: 'Protostar', duration: '100,000 years', description: 'Gravitational collapse begins' },
          { name: 'Main Sequence', duration: '100+ billion years', description: 'Hydrogen fusion' },
          { name: 'Red Dwarf', duration: 'Billions of years', description: 'Slow cooling' },
          { name: 'White Dwarf', duration: 'Trillions of years', description: 'Final cooling phase' },
        ],
      };
    } else if (star.mass < 8) {
      return {
        pathType: 'Medium Mass',
        stages: [
          { name: 'Molecular Cloud', duration: 'Millions of years', description: 'Gas and dust collapse' },
          { name: 'Protostar', duration: '100,000 years', description: 'Gravitational collapse begins' },
          { name: 'Main Sequence', duration: '10 billion years', description: 'Hydrogen fusion' },
          { name: 'Red Giant', duration: '1-2 billion years', description: 'Shell burning' },
          { name: 'Planetary Nebula', duration: '10,000 years', description: 'Outer layers ejected' },
          { name: 'White Dwarf', duration: 'Trillions of years', description: 'Final cooling phase' },
        ],
      };
    } else if (star.mass < 20) {
      return {
        pathType: 'High Mass',
        stages: [
          { name: 'Molecular Cloud', duration: 'Millions of years', description: 'Gas and dust collapse' },
          { name: 'Protostar', duration: '100,000 years', description: 'Rapid gravitational collapse' },
          { name: 'Massive Main Sequence', duration: '10 million years', description: 'Rapid hydrogen fusion' },
          { name: 'Supergiant', duration: '1 million years', description: 'Rapid expansion and cooling' },
          { name: 'Supernova', duration: 'Seconds to minutes', description: 'Catastrophic explosion' },
          { name: 'Neutron Star', duration: 'Billions of years', description: 'Extreme density remnant' },
        ],
      };
    } else {
      return {
        pathType: 'Very High Mass',
        stages: [
          { name: 'Molecular Cloud', duration: 'Millions of years', description: 'Gas and dust collapse' },
          { name: 'Protostar', duration: '100,000 years', description: 'Rapid gravitational collapse' },
          { name: 'Massive Main Sequence', duration: '1-10 million years', description: 'Extreme fusion' },
          { name: 'Hypergiant', duration: '100,000 years', description: 'Extreme expansion' },
          { name: 'Supernova', duration: 'Seconds to minutes', description: 'Catastrophic explosion' },
          { name: 'Black Hole', duration: 'Infinite', description: 'Extreme density remnant' },
        ],
      };
    }
  }, [star]);

  if (!star || !lifecyclePath) {
    return (
      <Card className="bg-slate-900 border-cyan-500/30 p-6 h-full flex items-center justify-center">
        <div className="text-center text-slate-400">
          <p className="text-lg font-semibold">Select a star to view lifecycle</p>
        </div>
      </Card>
    );
  }

  const currentStageIndex = lifecyclePath.stages.findIndex(
    (stage) => stage.name.toLowerCase().includes(star.lifecycleStage.split(' ')[0].toLowerCase())
  );

  return (
    <Card className="bg-gradient-to-b from-slate-900 to-slate-950 border-cyan-500/30 p-6 h-full overflow-y-auto">
      <div className="space-y-6">
        <div className="border-b border-cyan-500/20 pb-4">
          <h2 className="text-xl font-bold text-cyan-300 mb-2">Stellar Lifecycle</h2>
          <Badge className="bg-cyan-500/20 text-cyan-300 border border-cyan-500/50">
            {lifecyclePath.pathType} Star (Mass: {star.mass.toFixed(2)} M☉)
          </Badge>
        </div>

        <div className="space-y-4">
          {lifecyclePath.stages.map((stage, index) => (
            <div key={index} className="relative">
              {index < lifecyclePath.stages.length - 1 && (
                <div className="absolute left-5 top-12 w-0.5 h-8 bg-gradient-to-b from-cyan-400 to-slate-600"></div>
              )}

              <div className="flex gap-4">
                <div className="relative flex flex-col items-center">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                      index === currentStageIndex
                        ? 'bg-cyan-400 text-slate-900 ring-2 ring-cyan-300 scale-125'
                        : index < currentStageIndex
                        ? 'bg-green-500/30 text-green-300 border border-green-500'
                        : 'bg-slate-700 text-slate-300 border border-slate-600'
                    }`}
                  >
                    {index + 1}
                  </div>
                </div>

                <div className={`flex-1 pt-1 pb-4 ${
                  index === currentStageIndex ? 'bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-3' : ''
                }`}>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className={`font-semibold ${
                        index === currentStageIndex ? 'text-cyan-300' : 'text-slate-200'
                      }`}>
                        {stage.name}
                        {index === currentStageIndex && (
                          <span className="ml-2 text-xs bg-cyan-400/20 text-cyan-300 px-2 py-1 rounded">Current</span>
                        )}
                      </h4>
                      <p className="text-xs text-slate-400 mt-1">{stage.description}</p>
                    </div>
                    <span className="text-xs text-slate-400 whitespace-nowrap mt-0.5">{stage.duration}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 bg-slate-800/50 border border-cyan-500/20 rounded-lg mt-4">
          <h3 className="text-sm font-semibold text-cyan-400 mb-2">Estimated Age</h3>
          <p className="text-sm text-slate-300">
            {star.mass > 8
              ? 'Young star: likely millions of years old'
              : star.mass > 1.5
              ? 'Middle-aged star: likely billions of years old'
              : 'Ancient star: could be billions to trillions of years old'}
          </p>
        </div>
      </div>
    </Card>
  );
};

export default LifecycleTimeline;
