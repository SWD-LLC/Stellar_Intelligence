import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface ElementOriginProps {
  star: { name: string; spectralClass: string; mass: number } | null;
}

const ElementOrigin: React.FC<ElementOriginProps> = ({ star }) => {
  if (!star) {
    return (
      <Card className="bg-slate-900 border-cyan-500/30 p-6 h-full flex items-center justify-center">
        <div className="text-center text-slate-400">
          <p className="text-lg font-semibold">Select a star to view element origins</p>
        </div>
      </Card>
    );
  }

  const getElementsForStar = (mass: number) => {
    const elements: Array<{ name: string; symbol: string; abundance: number; origin: string }> = [];

    if (mass < 0.5) {
      elements.push(
        { name: 'Hydrogen', symbol: 'H', abundance: 73, origin: 'Primordial' },
        { name: 'Helium', symbol: 'He', abundance: 25, origin: 'Primordial' },
        { name: 'Carbon', symbol: 'C', abundance: 0.5, origin: 'Primordial' },
        { name: 'Nitrogen', symbol: 'N', abundance: 0.1, origin: 'Primordial' },
        { name: 'Oxygen', symbol: 'O', abundance: 0.8, origin: 'Primordial' }
      );
    } else if (mass < 8) {
      elements.push(
        { name: 'Hydrogen', symbol: 'H', abundance: 71, origin: 'Primordial' },
        { name: 'Helium', symbol: 'He', abundance: 27, origin: 'Primordial + Fusion' },
        { name: 'Carbon', symbol: 'C', abundance: 0.5, origin: 'Triple-alpha process' },
        { name: 'Nitrogen', symbol: 'N', abundance: 0.3, origin: 'CNO cycle' },
        { name: 'Oxygen', symbol: 'O', abundance: 0.8, origin: 'Fusion' },
        { name: 'Neon', symbol: 'Ne', abundance: 0.2, origin: 'Fusion' }
      );
    } else if (mass < 20) {
      elements.push(
        { name: 'Hydrogen', symbol: 'H', abundance: 70, origin: 'Primordial' },
        { name: 'Helium', symbol: 'He', abundance: 28, origin: 'Fusion' },
        { name: 'Carbon', symbol: 'C', abundance: 0.4, origin: 'Triple-alpha' },
        { name: 'Nitrogen', symbol: 'N', abundance: 0.5, origin: 'CNO cycle' },
        { name: 'Oxygen', symbol: 'O', abundance: 0.9, origin: 'Fusion' },
        { name: 'Neon', symbol: 'Ne', abundance: 0.3, origin: 'Fusion' },
        { name: 'Magnesium', symbol: 'Mg', abundance: 0.15, origin: 'Fusion' },
        { name: 'Silicon', symbol: 'Si', abundance: 0.1, origin: 'Fusion' },
        { name: 'Iron', symbol: 'Fe', abundance: 0.05, origin: 'Supernova' }
      );
    } else {
      elements.push(
        { name: 'Hydrogen', symbol: 'H', abundance: 68, origin: 'Primordial' },
        { name: 'Helium', symbol: 'He', abundance: 30, origin: 'Rapid fusion' },
        { name: 'Carbon', symbol: 'C', abundance: 0.3, origin: 'Triple-alpha' },
        { name: 'Nitrogen', symbol: 'N', abundance: 0.6, origin: 'CNO cycle' },
        { name: 'Oxygen', symbol: 'O', abundance: 1.0, origin: 'Fusion' },
        { name: 'Neon', symbol: 'Ne', abundance: 0.4, origin: 'Fusion' },
        { name: 'Magnesium', symbol: 'Mg', abundance: 0.2, origin: 'Fusion' },
        { name: 'Silicon', symbol: 'Si', abundance: 0.2, origin: 'Fusion' },
        { name: 'Iron', symbol: 'Fe', abundance: 0.15, origin: 'Supernova' },
        { name: 'Nickel', symbol: 'Ni', abundance: 0.05, origin: 'Supernova' }
      );
    }

    return elements;
  };

  const elements = getElementsForStar(star.mass);

  return (
    <Card className="bg-gradient-to-b from-slate-900 to-slate-950 border-cyan-500/30 p-6 h-full overflow-y-auto">
      <div className="space-y-6">
        <div className="border-b border-cyan-500/20 pb-4">
          <h2 className="text-xl font-bold text-cyan-300 mb-2">Element Origins</h2>
          <p className="text-sm text-slate-400">Nucleosynthesis in {star.name}</p>
        </div>

        <div className="space-y-3">
          {elements.map((element, index) => (
            <div key={index} className="p-3 bg-slate-800/30 border border-cyan-500/10 rounded-lg hover:border-cyan-500/30 transition-colors">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-white font-bold text-sm">
                    {element.symbol}
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-cyan-300">{element.name}</h4>
                    <p className="text-xs text-slate-400">{element.origin}</p>
                  </div>
                </div>
                <Badge className="bg-cyan-500/20 text-cyan-300 border border-cyan-500/50">
                  {element.abundance}%
                </Badge>
              </div>
              <div className="w-full bg-slate-700 rounded-full h-1.5">
                <div
                  className="bg-gradient-to-r from-cyan-400 to-blue-400 h-1.5 rounded-full transition-all duration-300"
                  style={{ width: `${element.abundance}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 bg-slate-800/50 border border-cyan-500/20 rounded-lg">
          <h3 className="text-sm font-semibold text-cyan-400 mb-2">Nucleosynthesis Processes</h3>
          <ul className="space-y-1 text-xs text-slate-300">
            <li>• <span className="text-cyan-300">Primordial:</span> Created in Big Bang</li>
            <li>• <span className="text-cyan-300">Fusion:</span> Created in stellar core</li>
            <li>• <span className="text-cyan-300">CNO Cycle:</span> Carbon-Nitrogen-Oxygen fusion</li>
            <li>• <span className="text-cyan-300">Supernova:</span> Created in explosion</li>
          </ul>
        </div>
      </div>
    </Card>
  );
};

export default ElementOrigin;
