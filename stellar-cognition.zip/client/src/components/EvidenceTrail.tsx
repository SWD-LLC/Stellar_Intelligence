import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, AlertCircle } from 'lucide-react';

interface EvidenceTrailProps {
  star: { name: string; spectralClass: string; temperature: number; luminosity: number } | null;
}

const EvidenceTrail: React.FC<EvidenceTrailProps> = ({ star }) => {
  if (!star) {
    return (
      <Card className="bg-slate-900 border-cyan-500/30 p-6 h-full flex items-center justify-center">
        <div className="text-center text-slate-400">
          <p className="text-lg font-semibold">Select a star to view evidence</p>
        </div>
      </Card>
    );
  }

  const evidenceItems = [
    {
      label: 'Spectral Class',
      value: `Classification: ${star.spectralClass}`,
    },
    {
      label: 'Temperature',
      value: `Surface temperature: ${star.temperature}K indicates spectral type`,
    },
    {
      label: 'Luminosity',
      value: `Luminosity of ${star.luminosity.toFixed(2)} L☉ places star on H-R diagram`,
    },
    {
      label: 'Color Index',
      value: `Color index consistent with ${star.spectralClass} classification`,
    },
    {
      label: 'Catalog Source',
      value: 'Data from Hipparcos and Gaia DR3 catalogs',
    },
  ];

  return (
    <Card className="bg-gradient-to-b from-slate-900 to-slate-950 border-cyan-500/30 p-6 h-full overflow-y-auto">
      <div className="space-y-6">
        <div className="border-b border-cyan-500/20 pb-4">
          <h2 className="text-xl font-bold text-cyan-300 mb-2">Evidence Trail</h2>
          <p className="text-sm text-slate-400">Classification reasoning for {star.name}</p>
        </div>

        <div className="p-4 bg-slate-800/50 border border-cyan-500/20 rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold text-cyan-400">Classification Confidence</span>
            <Badge className="bg-green-500/20 text-green-300 border border-green-500/50">
              85.0%
            </Badge>
          </div>
          <div className="w-full bg-slate-700 rounded-full h-2">
            <div
              className="bg-gradient-to-r from-cyan-400 to-green-400 h-2 rounded-full transition-all duration-300"
              style={{ width: '85%' }}
            ></div>
          </div>
        </div>

        <div className="space-y-3">
          {evidenceItems.map((item, index) => (
            <div key={index} className="p-3 bg-slate-800/30 border border-cyan-500/10 rounded-lg hover:border-cyan-500/30 transition-colors">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-semibold text-cyan-300 mb-1">{item.label}</h4>
                  <p className="text-xs text-slate-300 leading-relaxed">{item.value}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 bg-cyan-500/5 border border-cyan-500/20 rounded-lg">
          <h3 className="text-sm font-semibold text-cyan-400 mb-3">Reasoning Chain</h3>
          <ol className="space-y-2 text-xs text-slate-300">
            <li className="flex gap-2">
              <span className="text-cyan-400 font-bold">1.</span>
              <span>Spectral class indicates a {star.spectralClass.charAt(0)} type star</span>
            </li>
            <li className="flex gap-2">
              <span className="text-cyan-400 font-bold">2.</span>
              <span>Temperature of {star.temperature}K confirms spectral classification</span>
            </li>
            <li className="flex gap-2">
              <span className="text-cyan-400 font-bold">3.</span>
              <span>Luminosity of {star.luminosity.toFixed(2)} L☉ determines evolutionary stage</span>
            </li>
            <li className="flex gap-2">
              <span className="text-cyan-400 font-bold">4.</span>
              <span>H-R placement confirms stellar classification and lifecycle stage</span>
            </li>
          </ol>
        </div>
      </div>
    </Card>
  );
};

export default EvidenceTrail;
