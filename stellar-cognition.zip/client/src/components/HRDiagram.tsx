import React, { useMemo, useState } from 'react';
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';

interface Star {
  id: number;
  name: string;
  temperature: number;
  luminosity: number;
  spectralClass: string;
  lifecycleStage: string;
}

interface HRDiagramProps {
  stars: Star[];
  selectedStarId?: number;
  onStarSelect: (starId: number) => void;
}

const HRDiagram: React.FC<HRDiagramProps> = ({ stars, selectedStarId, onStarSelect }) => {
  const [hoveredStar, setHoveredStar] = useState<number | null>(null);

  const chartData = useMemo(() => {
    return stars.map((star) => ({
      id: star.id,
      name: star.name,
      x: Math.log10(star.temperature),
      y: Math.log10(star.luminosity),
      temperature: star.temperature,
      luminosity: star.luminosity,
      spectralClass: star.spectralClass,
      lifecycleStage: star.lifecycleStage,
    }));
  }, [stars]);

  const getStarColor = (spectralClass: string): string => {
    const firstLetter = spectralClass.charAt(0);
    const colorMap: Record<string, string> = {
      O: '#3366ff',
      B: '#6699ff',
      A: '#ccddff',
      F: '#ffff99',
      G: '#ffff00',
      K: '#ff9933',
      M: '#ff3333',
    };
    return colorMap[firstLetter] || '#cccccc';
  };

  const handleStarClick = (data: any) => {
    onStarSelect(data.id);
  };

  const CustomTooltip = (props: any) => {
    const { active, payload } = props;
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-900 border border-cyan-400 rounded p-2 text-xs text-white">
          <p className="font-semibold text-cyan-300">{data.name}</p>
          <p>Class: {data.spectralClass}</p>
          <p>Temp: {data.temperature}K</p>
          <p>Luminosity: {data.luminosity.toFixed(2)} L☉</p>
          <p>Stage: {data.lifecycleStage}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full h-full bg-gradient-to-b from-slate-950 to-slate-900 rounded-lg p-4 border border-cyan-500/30 animate-fade-in-up">
      <h3 className="text-lg font-semibold text-cyan-300 mb-4 animate-slide-in-left">Hertzsprung-Russell Diagram</h3>
      
      <ResponsiveContainer width="100%" height={400}>
        <ScatterChart margin={{ top: 20, right: 20, bottom: 60, left: 60 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
          <XAxis
            type="number"
            dataKey="x"
            name="Temperature (log K)"
            label={{ value: 'Temperature (log K)', position: 'insideBottomRight', offset: -40, fill: '#06b6d4' }}
            tick={{ fill: '#06b6d4', fontSize: 12 }}
            reversed
          />
          <YAxis
            type="number"
            dataKey="y"
            name="Luminosity (log L☉)"
            label={{ value: 'Luminosity (log L☉)', angle: -90, position: 'insideLeft', fill: '#06b6d4' }}
            tick={{ fill: '#06b6d4', fontSize: 12 }}
          />
          <Tooltip content={<CustomTooltip />} />
          
          <Scatter name="Stars" data={chartData} onClick={(data: any) => handleStarClick(data)}>
            {chartData.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={getStarColor(entry.spectralClass)}
                opacity={
                  selectedStarId === entry.id
                    ? 1
                    : hoveredStar === entry.id
                    ? 0.8
                    : 0.6
                }
                style={{
                  cursor: 'pointer',
                  filter:
                    selectedStarId === entry.id
                      ? 'drop-shadow(0 0 8px #06b6d4)'
                      : hoveredStar === entry.id
                      ? 'drop-shadow(0 0 4px #06b6d4)'
                      : 'none',
                }}
              />
            ))}
          </Scatter>
        </ScatterChart>
      </ResponsiveContainer>

      <div className="mt-4 grid grid-cols-2 gap-2 text-xs text-slate-300">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-cyan-400 rounded-full"></div>
          <span>Main Sequence</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-orange-400 rounded-full"></div>
          <span>Red Giants</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-blue-300 rounded-full"></div>
          <span>Supergiants</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-gray-300 rounded-full"></div>
          <span>White Dwarfs</span>
        </div>
      </div>

      {selectedStarId && (
        <div className="mt-4 p-2 bg-slate-800 border border-cyan-400/50 rounded text-xs text-cyan-300">
          <p>Selected: {chartData.find((d) => d.id === selectedStarId)?.name}</p>
        </div>
      )}
    </div>
  );
};

export default HRDiagram;
