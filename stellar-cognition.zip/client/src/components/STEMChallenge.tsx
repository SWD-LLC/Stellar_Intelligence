import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CheckCircle2, XCircle, Lightbulb } from 'lucide-react';

interface Challenge {
  id: number;
  question: string;
  options: string[];
  correct: number;
  explanation: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
}

interface STEMChallengeProps {
  star: {
    name: string;
    spectralClass: string;
    temperature: number;
    luminosity: number;
    mass: number;
  } | null;
}

const STEMChallenge: React.FC<STEMChallengeProps> = ({ star }) => {
  const [currentChallenge, setCurrentChallenge] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [score, setScore] = useState(0);

  if (!star) {
    return (
      <Card className="bg-slate-900 border-cyan-500/30 p-6 h-full flex items-center justify-center">
        <div className="text-center text-slate-400">
          <p className="text-lg font-semibold">Select a star for STEM challenges</p>
        </div>
      </Card>
    );
  }

  const getChallenges = (s: typeof star): Challenge[] => {
    if (!s) return [];
    return [
      {
        id: 1,
        question: `What is the approximate surface temperature of ${s.name}?`,
        options: [`${Math.round(s.temperature / 1000) * 1000}K`, `${Math.round(s.temperature / 1000 + 2) * 1000}K`, `${Math.round(s.temperature / 1000 - 2) * 1000}K`, `${Math.round(s.temperature / 1000 + 5) * 1000}K`],
        correct: 0,
        explanation: `${s.name} has a surface temperature of approximately ${s.temperature}K, which determines its spectral class and color.`,
        difficulty: 'Easy',
      },
      {
        id: 2,
        question: `Which spectral class does ${s.name} belong to?`,
        options: [s.spectralClass, s.spectralClass.charAt(0) + 'M', s.spectralClass.charAt(0) + 'B', s.spectralClass.charAt(0) + 'A'],
        correct: 0,
        explanation: `${s.name} is classified as spectral type ${s.spectralClass}, which is determined by its temperature and composition.`,
        difficulty: 'Easy',
      },
      {
        id: 3,
        question: `If ${s.name} has a luminosity of ${s.luminosity.toFixed(2)} L☉, how much brighter is it than the Sun?`,
        options: [`${Math.round(s.luminosity)}x brighter`, `${Math.round(s.luminosity / 2)}x brighter`, `${Math.round(s.luminosity * 2)}x brighter`, 'Dimmer than the Sun'],
        correct: 0,
        explanation: `With a luminosity of ${s.luminosity.toFixed(2)} L☉, ${s.name} is approximately ${Math.round(s.luminosity)} times brighter than our Sun.`,
        difficulty: 'Medium',
      },
      {
        id: 4,
        question: `What is the relationship between ${s.name}'s mass (${s.mass.toFixed(2)} M☉) and its luminosity?`,
        options: ['Mass-Luminosity Relation: L ∝ M^3.5', 'Luminosity is independent of mass', 'More massive stars are always dimmer', 'Mass and luminosity are inversely related'],
        correct: 0,
        explanation: 'The mass-luminosity relation shows that stellar luminosity is approximately proportional to the 3.5th power of the star\'s mass.',
        difficulty: 'Hard',
      },
      {
        id: 5,
        question: `On the H-R Diagram, where would ${s.name} be located?`,
        options: ['Main Sequence', 'Red Giant Branch', 'White Dwarf Region', 'Supergiant Region'],
        correct: s.luminosity > 10 ? (s.temperature < 5000 ? 1 : 3) : 0,
        explanation: `Based on its temperature and luminosity, ${s.name} would be located in the ${s.luminosity > 10 ? (s.temperature < 5000 ? 'Red Giant' : 'Supergiant') : 'Main Sequence'} region.`,
        difficulty: 'Medium',
      },
    ];
  };

  const challenges = getChallenges(star);
  const challenge = challenges[currentChallenge];

  const handleAnswer = (index: number) => {
    if (!answered) {
      setSelectedAnswer(index);
      setAnswered(true);
      if (index === challenge.correct) {
        setScore(score + 1);
      }
    }
  };

  const handleNext = () => {
    if (currentChallenge < challenges.length - 1) {
      setCurrentChallenge(currentChallenge + 1);
      setSelectedAnswer(null);
      setAnswered(false);
    }
  };

  const handleReset = () => {
    setCurrentChallenge(0);
    setSelectedAnswer(null);
    setAnswered(false);
    setScore(0);
  };

  const isComplete = currentChallenge === challenges.length - 1 && answered;

  return (
    <Card className="bg-gradient-to-b from-slate-900 to-slate-950 border-cyan-500/30 p-6 h-full overflow-y-auto">
      <div className="space-y-6">
        <div className="border-b border-cyan-500/20 pb-4">
          <h2 className="text-xl font-bold text-cyan-300 mb-2">STEM Challenge Mode</h2>
          <div className="flex items-center justify-between">
            <p className="text-sm text-slate-400">Test your stellar knowledge</p>
            <Badge className="bg-cyan-500/20 text-cyan-300 border border-cyan-500/50">
              {currentChallenge + 1} / {challenges.length}
            </Badge>
          </div>
        </div>

        <div className="p-4 bg-slate-800/50 border border-cyan-500/20 rounded-lg">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-cyan-400">Question {currentChallenge + 1}</h3>
            <Badge
              className={`text-xs ${
                challenge.difficulty === 'Easy'
                  ? 'bg-green-500/20 text-green-300 border border-green-500/50'
                  : challenge.difficulty === 'Medium'
                  ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/50'
                  : 'bg-red-500/20 text-red-300 border border-red-500/50'
              }`}
            >
              {challenge.difficulty}
            </Badge>
          </div>
          <p className="text-sm text-slate-200 font-semibold">{challenge.question}</p>
        </div>

        <div className="space-y-2">
          {challenge.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswer(index)}
              disabled={answered}
              className={`w-full p-3 text-left rounded-lg border transition-all ${
                selectedAnswer === index
                  ? index === challenge.correct
                    ? 'bg-green-500/20 border-green-500/50 text-green-300'
                    : 'bg-red-500/20 border-red-500/50 text-red-300'
                  : 'bg-slate-800/30 border-cyan-500/10 text-slate-300 hover:border-cyan-500/30'
              } ${answered ? 'cursor-default' : 'cursor-pointer'}`}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm">{option}</span>
                {answered && selectedAnswer === index && (
                  <div>
                    {index === challenge.correct ? (
                      <CheckCircle2 className="w-5 h-5 text-green-400" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-400" />
                    )}
                  </div>
                )}
              </div>
            </button>
          ))}
        </div>

        {answered && (
          <div className="p-4 bg-cyan-500/5 border border-cyan-500/20 rounded-lg">
            <div className="flex items-start gap-2 mb-2">
              <Lightbulb className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-semibold text-cyan-300 mb-1">Explanation</h4>
                <p className="text-xs text-slate-300">{challenge.explanation}</p>
              </div>
            </div>
          </div>
        )}

        <div className="flex gap-2">
          {!isComplete ? (
            <Button
              onClick={handleNext}
              disabled={!answered}
              className="w-full bg-cyan-500 hover:bg-cyan-600 text-white"
            >
              {currentChallenge === challenges.length - 1 ? 'Finish' : 'Next Question'}
            </Button>
          ) : (
            <div className="w-full space-y-3">
              <div className="p-4 bg-slate-800/50 border border-cyan-500/20 rounded-lg text-center">
                <p className="text-sm text-slate-400 mb-1">Final Score</p>
                <p className="text-3xl font-bold text-cyan-300">
                  {score} / {challenges.length}
                </p>
                <p className="text-xs text-slate-400 mt-2">
                  {Math.round((score / challenges.length) * 100)}% Correct
                </p>
              </div>
              <Button
                onClick={handleReset}
                className="w-full bg-cyan-500 hover:bg-cyan-600 text-white"
              >
                Try Again
              </Button>
            </div>
          )}
        </div>
      </div>
    </Card>
  );
};

export default STEMChallenge;
