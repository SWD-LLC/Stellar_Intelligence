import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Spinner } from '@/components/ui/spinner';
import { Binoculars, Eye, Telescope, AlertCircle } from 'lucide-react';

interface TelescopeCoachProps {
  star: { name: string; distance: number; luminosity: number; constellation: string } | null;
}

const TelescopeCoach: React.FC<TelescopeCoachProps> = ({ star }) => {
  const [expanded, setExpanded] = useState(false);

  if (!star) {
    return (
      <Card className="bg-slate-900 border-cyan-500/30 p-6 h-full flex items-center justify-center">
        <div className="text-center text-slate-400">
          <p className="text-lg font-semibold">Select a star for observation tips</p>
        </div>
      </Card>
    );
  }

  const getObservationTips = (distance: number, luminosity: number) => {
    const tips: Array<{ icon: React.ReactNode; title: string; description: string; difficulty: string }> = [];

    if (distance < 10) {
      tips.push({
        icon: <Eye className="w-5 h-5" />,
        title: 'Naked Eye Observable',
        description: 'This star is bright enough to see without any equipment',
        difficulty: 'Easy',
      });
    } else if (distance < 100) {
      tips.push({
        icon: <Binoculars className="w-5 h-5" />,
        title: 'Binoculars Recommended',
        description: 'Use 10x50 binoculars for optimal viewing',
        difficulty: 'Easy',
      });
    } else {
      tips.push({
        icon: <Telescope className="w-5 h-5" />,
        title: 'Telescope Required',
        description: 'Use a 6-inch or larger telescope for best results',
        difficulty: 'Moderate',
      });
    }

    if (luminosity > 100) {
      tips.push({
        icon: <AlertCircle className="w-5 h-5" />,
        title: 'Very Bright Star',
        description: 'Use neutral density filters to avoid eye damage',
        difficulty: 'Important',
      });
    }

    return tips;
  };

  const tips = getObservationTips(star.distance, star.luminosity);

  return (
    <Card className="bg-gradient-to-b from-slate-900 to-slate-950 border-cyan-500/30 p-6 h-full overflow-y-auto">
      <div className="space-y-6">
        <div className="border-b border-cyan-500/20 pb-4">
          <h2 className="text-xl font-bold text-cyan-300 mb-2">AI Telescope Coach</h2>
          <p className="text-sm text-slate-400">Observation guidance for {star.name}</p>
        </div>

        <div className="p-4 bg-slate-800/50 border border-cyan-500/20 rounded-lg">
          <h3 className="text-sm font-semibold text-cyan-400 mb-3">Observation Details</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Location:</span>
              <span className="text-cyan-300 font-semibold">{star.constellation}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Distance:</span>
              <span className="text-cyan-300 font-semibold">{star.distance.toFixed(2)} light-years</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Brightness:</span>
              <span className="text-cyan-300 font-semibold">{star.luminosity.toFixed(2)} L☉</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Best Season:</span>
              <span className="text-cyan-300 font-semibold">Year-round</span>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-cyan-400">Observation Tips</h3>
          {tips.map((tip, index) => (
            <div key={index} className="p-3 bg-slate-800/30 border border-cyan-500/10 rounded-lg hover:border-cyan-500/30 transition-colors">
              <div className="flex items-start gap-3">
                <div className="text-cyan-400 flex-shrink-0 mt-0.5">{tip.icon}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <h4 className="text-sm font-semibold text-cyan-300">{tip.title}</h4>
                    <Badge
                      className={`text-xs ${
                        tip.difficulty === 'Easy'
                          ? 'bg-green-500/20 text-green-300 border border-green-500/50'
                          : tip.difficulty === 'Moderate'
                          ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/50'
                          : 'bg-red-500/20 text-red-300 border border-red-500/50'
                      }`}
                    >
                      {tip.difficulty}
                    </Badge>
                  </div>
                  <p className="text-xs text-slate-300">{tip.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 bg-cyan-500/5 border border-cyan-500/20 rounded-lg">
          <h3 className="text-sm font-semibold text-cyan-400 mb-2">Sky Watching Tips</h3>
          <ul className="space-y-2 text-xs text-slate-300">
            <li>• Observe during twilight for best contrast</li>
            <li>• Allow 20-30 minutes for eye adaptation</li>
            <li>• Use red flashlight to preserve night vision</li>
            <li>• Check weather forecast for clear skies</li>
            <li>• Avoid light pollution areas when possible</li>
          </ul>
        </div>
      </div>
    </Card>
  );
};

export default TelescopeCoach;
