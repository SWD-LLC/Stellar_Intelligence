import React, { useState } from 'react';
import { trpc } from '@/lib/trpc';
import HRDiagram from '@/components/HRDiagram';
import StarBiography from '@/components/StarBiography';
import ModeTabs from '@/components/ModeTabs';
import EvidenceTrail from '@/components/EvidenceTrail';
import LifecycleTimeline from '@/components/LifecycleTimeline';
import ElementOrigin from '@/components/ElementOrigin';
import TelescopeCoach from '@/components/TelescopeCoach';
import STEMChallenge from '@/components/STEMChallenge';
import ReportGenerator from '@/components/ReportGenerator';
import { Spinner } from '@/components/ui/spinner';
import { toast } from 'sonner';

type Mode = 'student' | 'public' | 'research' | 'nasa_stem';

interface Star {
  id: number;
  name: string;
  spectralClass: string;
  temperature: number;
  luminosity: number;
  distance: number;
  mass: number;
  radius: number;
  constellation: string;
  lifecycleStage: string;
  confidenceScore: number;
  dataSource: string;
  uncertaintyNote: string | null | undefined;
  elementOrigins: any[];
}

const Stellar: React.FC = () => {
  const [selectedStarId, setSelectedStarId] = useState<number | undefined>();
  const [selectedStar, setSelectedStar] = useState<Star | null>(null);

  const { data: allStars, isLoading: starsLoading } = trpc.stellar.getAllStars.useQuery();
  const { data: starDetail, isLoading: detailLoading } = trpc.stellar.getStarDetail.useQuery(
    { starId: selectedStarId! },
    { enabled: !!selectedStarId }
  );

  const generateExplanationMutation = trpc.stellar.generateExplanation.useMutation();

  const handleGenerateExplanation = async (mode: Mode) => {
    if (!selectedStarId) return { explanation: '' };
    try {
      const result = await generateExplanationMutation.mutateAsync({
        starId: selectedStarId,
        mode,
      });
      return result;
    } catch (error) {
      console.error('Failed to generate explanation:', error);
      toast.error('Failed to generate explanation');
      return { explanation: 'Error generating explanation' };
    }
  };

  React.useEffect(() => {
    if (starDetail) {
      setSelectedStar(starDetail);
    }
  }, [starDetail]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-4 md:p-6">
      <div className="mb-6">
        <h1 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-cyan-400 to-blue-400 mb-2">
          Stellar Cognition
        </h1>
        <p className="text-slate-400 text-lg">AI-Enhanced Hertzsprung-Russell Diagram and Stellar Classification</p>
      </div>

      {starsLoading ? (
        <div className="flex items-center justify-center h-96 gap-3">
          <Spinner className="w-8 h-8" />
          <span className="text-slate-300">Loading stellar data...</span>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            {allStars && (
              <HRDiagram
                stars={allStars}
                selectedStarId={selectedStarId}
                onStarSelect={setSelectedStarId}
              />
            )}
          </div>

          <div className="lg:col-span-1">
            {detailLoading ? (
              <div className="flex items-center justify-center h-96 gap-3">
                <Spinner className="w-6 h-6" />
                <span className="text-slate-300">Loading details...</span>
              </div>
            ) : (
              <StarBiography star={selectedStar} />
            )}
          </div>
        </div>
      )}

      {selectedStar && (
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <ModeTabs
              starId={selectedStar.id}
              starName={selectedStar.name}
              onGenerateExplanation={handleGenerateExplanation}
            />
          </div>
          <div>
            <EvidenceTrail star={selectedStar} />
          </div>
        </div>
      )}

      {selectedStar && (
        <div className="mt-6">
          <LifecycleTimeline star={selectedStar} />
        </div>
      )}

      {selectedStar && (
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <ElementOrigin star={selectedStar} />
          </div>
          <div>
            <TelescopeCoach star={selectedStar} />
          </div>
        </div>
      )}

      {selectedStar && (
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <STEMChallenge star={selectedStar} />
          </div>
          <div>
            <ReportGenerator star={selectedStar} />
          </div>
        </div>
      )}
    </div>
  );
};

export default Stellar;
