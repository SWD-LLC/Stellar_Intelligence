# Stellar Cognition - Project TODO

## Core Features

### Database & Data Models
- [x] Create stars table with complete stellar data (name, spectral_class, temperature, luminosity, distance, mass, radius, constellation, lifecycle_stage, element_origins, confidence_score, data_source)
- [x] Create observation_sessions table for tracking user interactions
- [x] Create hr_placements table for H-R diagram positioning
- [x] Create ai_explanations table for caching LLM responses by mode
- [x] Create evidence_records table for classification reasoning chains
- [x] Create lifecycle_paths table for stellar evolution data
- [x] Create element_origins table for nucleosynthesis information
- [x] Create stellar_reports table for generated reports
- [x] Create stem_challenges table for challenge mode tasks
- [x] Seed database with 20+ real stars (Sun, Sirius A, Vega, Betelgeuse, Rigel, Proxima Centauri, Barnard's Star, Altair, Deneb, Antares, Aldebaran, Polaris, Arcturus, Spica, Capella, Fomalhaut, Alpha Centauri A, Epsilon Eridani, Procyon A, Sirius B, etc.)

### Interactive H-R Diagram
- [x] Build H-R Diagram component with D3/Recharts plotting stars by temperature vs luminosity
- [x] Implement clickable star selection with visual feedback
- [x] Add hover tooltips showing star name, spectral class, temperature, luminosity
- [ ] Implement zoom and pan functionality for diagram navigation
- [x] Add legend showing H-R regions (main sequence, red giants, white dwarfs, supergiants)
- [ ] Create star catalog list view as alternative selection method

### Star Biography Panel
- [ ] Build dynamic panel displaying selected star's detailed data
- [ ] Display: name, spectral class, temperature, luminosity, distance, mass, radius, constellation, lifecycle stage, confidence score, data source
- [ ] Add visual badges for star classification and lifecycle stage
- [ ] Implement smooth transitions when star selection changes

### Mode Tabs (Student, Public, Research, NASA/STEM)
- [ ] Create tab navigation component with four modes
- [ ] Implement Student Mode: simple, accessible explanations
- [ ] Implement Public Mode: poetic but accurate explanations
- [ ] Implement Research Mode: technical explanations with evidence citations
- [ ] Implement NASA/STEM Mode: outreach-style explanations connected to STEM learning
- [ ] Integrate LLM to generate mode-specific explanations
- [ ] Cache explanations in database to avoid redundant API calls

### Evidence Trail Panel
- [ ] Build evidence panel showing classification reasoning chain
- [ ] Display: spectral class evidence, temperature evidence, luminosity evidence, color evidence, catalog/source evidence
- [ ] Show confidence level and missing data warnings
- [ ] Present step-by-step reasoning (e.g., "Spectral class indicates cool surface → Luminosity is extremely high → Large radius explains brightness")

### Stellar Lifecycle Timeline
- [ ] Build animated lifecycle component showing evolutionary path
- [ ] Implement low/medium mass path: molecular cloud → protostar → main sequence → red giant → planetary nebula → white dwarf
- [ ] Implement high mass path: molecular cloud → protostar → massive main sequence → supergiant → supernova → neutron star/black hole
- [ ] Implement white dwarf cooling track
- [ ] Highlight current lifecycle stage for selected star
- [ ] Add timeline labels and stage descriptions

### Element Origin Overlay
- [ ] Build element legacy panel showing nucleosynthesis contributions
- [ ] Main sequence stars: hydrogen to helium fusion
- [ ] Red giants: carbon, nitrogen, oxygen contribution
- [ ] Massive stars: oxygen, silicon, iron pathway
- [ ] Supernova pathway: heavy element distribution
- [ ] Neutron merger note for gold/platinum context
- [ ] Display as interactive periodic table or element list with abundance percentages

### AI Telescope Coach
- [ ] Build observation helper screen with input fields
- [ ] Inputs: image clarity, light pollution level, exposure length, location, time of night, target object
- [ ] Integrate LLM to generate observation guidance
- [ ] Provide recommendations: exposure adjustments, focus improvements, optimal observation timing, catalog mode suggestions
- [ ] Store observation sessions in database

### STEM Challenge Mode
- [ ] Build challenge screen with interactive tasks
- [ ] Challenge 1: Find a main sequence star
- [ ] Challenge 2: Compare a red giant to the Sun
- [ ] Challenge 3: Identify a white dwarf
- [ ] Challenge 4: Explain why blue stars live shorter lives
- [ ] Challenge 5: Trace a star lifecycle
- [ ] Implement challenge completion logic with validation
- [ ] Track completion status and user progress
- [ ] Add hints and feedback for each challenge

### Report Generator
- [ ] Build report generation interface with "Generate Stellar Report" button
- [ ] Report sections: observation summary, H-R placement, star biography, lifecycle interpretation, evidence trail, uncertainty statement, learning takeaway, suggested next observation
- [ ] Implement PDF export functionality
- [ ] Implement print-friendly HTML view
- [ ] Store generated reports in database
- [ ] Add report timestamp and metadata

### UI/UX & Design
- [ ] Implement mission-control dark interface (deep space color palette)
- [ ] Create observatory-grade dark theme with gold/cyan accents
- [ ] Add smooth animations and transitions throughout
- [ ] Implement responsive layout for desktop and tablet
- [ ] Create data-rich side panels with professional hierarchy
- [ ] Add confidence badges and evidence cards
- [ ] Implement interactive star catalog
- [ ] Remove all dead buttons and placeholder UI
- [ ] Add loading states and error handling

### Testing & Verification
- [ ] Write vitest tests for database queries
- [ ] Write vitest tests for LLM integration
- [ ] Write vitest tests for report generation
- [ ] Test H-R diagram interaction and star selection
- [ ] Test all mode tabs and explanation generation
- [ ] Test challenge mode completion logic
- [ ] Verify PDF export and print functionality
- [ ] Test responsive design across breakpoints
- [ ] Perform end-to-end testing of all features

## Completed Features
(none yet)
